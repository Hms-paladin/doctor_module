import React,{Component} from 'react';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import './advertise_master.css';
import { Select } from 'antd';
import 'antd/dist/antd.css';
class Advertisement extends Component
{
	constructor(props)
	{
		super(props);
		this.toggle = this.toggle.bind(this);
         this.state = {
          dropdownOpen: false
    };
	
}
  toggle() {
    this.setState(prevState => ({
      dropdownOpen: !prevState.dropdownOpen
    }));
  }
 

	render()
	{
		 const { Option } = Select;
		return(
			<div className="doctor_advertisement">
			<div className="doctor_border_box"><p className="clinic">Advertise Booking</p>
    
  </div>
      </div>
		);
	}
}
export default Advertisement;
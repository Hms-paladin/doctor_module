import React from "react";
import moment from "moment";
import { range } from "moment-range";
import Grid from '@material-ui/core/Grid';
import { CircleIndicator } from 'react-indicators';
import {Icon } from 'antd';
import './advertise_calendar.css'
import  Next from '../../images/previous.svg'
import Prev from '../../images/next.png'
// import SkipPreviousIcon from '@material-ui/icons/SkipPrevious';
// import SkipNextIcon from '@material-ui/icons/SkipNext';
import Moment from 'react-moment';
// import  {format} from 'moment';
import ArrowLeftIcon from '@material-ui/icons/ArrowLeft';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
 class CalendarBox extends React.Component {
  weekdayshort = moment.weekdaysShort();
  
  state = {
    showYearTable: false,
    showMonthTable: false,
    showDateTable:true,
    dateObject: moment(),
    allmonths: moment.months(),
    selectedDay:moment().format('DD'),
    SelectedMonth:moment.monthsShort(),
    selectedYear:null,
    input:false,
    selectvalue:"", 
    updatedcurrentDay:moment().format("dddd"),
   arr_store_month:" ",
    arr_store_month_value:"",
    arr_store_year: " ",
    arr_store_year_value: " ",
    currentyear:moment().format("YYYY"),
    currentmonth: moment().format("MMM"),
    selectDays:[]
    //ENDS 
  };  
  handleDateChange=(date)=>{
     alert(date)
    this.setState({
      selectedDate:date
    })
  }
  handleChange = event => {
    this.setState({ selectedvalue: event.target.value, name: event.target.name});
  };
  daysInMonth = () => {
    return this.state.dateObject.daysInMonth();
  };
  year = () => {
    return this.state.dateObject.format("Y");
  };
  currentDay = () => {
    return this.state.dateObject.format("D");
  };
  firstDayOfMonth = () => {
    let dateObject = this.state.dateObject;
    let firstDay = moment(dateObject)
      .startOf("month")
      .format("d"); // Day of week 0...1..5...6
    return firstDay;
  };
  month = () => {
    return this.state.dateObject.format("MMMM");
  };
  date=()=>
  {
    return this.state.dateObject.format("DD")
  }
  day=()=>
  {
    return this.state.dateObject.format("dddd")
  }
  showMonth = (e, month) => {
    this.setState({
      showMonthTable: !this.state.showMonthTable,
     showDateTable: !this.state.showDateTable
    });
  };
  setMonth = month => {
    let monthNo = this.state.allmonths.indexOf(month);
    let dateObject = Object.assign({}, this.state.dateObject);
    dateObject = moment(dateObject).set("month", monthNo);
    this.setState({
      dateObject: dateObject,
      showMonthTable: !this.state.showMonthTable,
      showDateTable: !this.state.showDateTable
    });
  };
  MonthList = props => {
    let months = [];
    props.data.map(data => {
      months.push(
        <td
          key={data}
          className="calendar-month"
          onClick={e => {
            this.setMonth(data);
          }}
        >
          <span>{data}</span>
        </td>
      );
    });
    let rows = [];
    let cells = [];

    months.forEach((row, i) => {
      if (i % 3 !== 0 || i == 0) {
        cells.push(row);
      } else {
        rows.push(cells);
        cells = [];
        cells.push(row);
      }
    });
    rows.push(cells);
    let monthlist = rows.map((d, i) => {
      return <tr>{d}</tr>;
    });

    return (
      <table className="calendar-month">
        <thead>
          <tr>
            <th colSpan="4">Select a Month</th>
          </tr>
        </thead>
        <tbody>{monthlist}</tbody>
      </table>
    );
  };
  showYearTable = e => {
    this.setState({
      showYearTable: !this.state.showYearTable,
      showDateTable: !this.state.showDateTable
    });
  };
    
  onPrev = () => {
    let curr = "";
    if (this.state.showYearTable === true) {
      curr = "year";
    } else {
      curr = "month";
    }
    this.setState({
      dateObject: this.state.dateObject.subtract(1, curr)
    });
  };
  onNext = () => {
    let curr = "";
    if (this.state.showYearTable === true) {
      curr = "year";
    } else {
      curr = "month";
    }
    this.setState({
      dateObject: this.state.dateObject.add(1, curr)
    });
  };
  setYear = year => {
    // alert(year)
    let dateObject = Object.assign({}, this.state.dateObject);
    dateObject = moment(dateObject).set("year", year);
    this.setState({
      dateObject: dateObject,
      showMonthTable: !this.state.showMonthTable,
      showYearTable: !this.state.showYearTable
    });
  };
  onYearChange = e => {
    this.setYear(e.target.value);
  };
  getDates(startDate, stopDate) {

    var dateArray = [];
    var currentDate = moment(startDate);
    var stopDate = moment(stopDate);
    while (currentDate <= stopDate) {
      dateArray.push(moment(currentDate).format("YYYY"));
      currentDate = moment(currentDate).add(1, "year");
    }
    return dateArray;
    console.log(dateArray)
  }
  YearTable = props => {
    let months = [];
    let nextten = moment()
      .set("year", props)
      .add("year", 12)
      .format("Y");

    let tenyear = this.getDates(props, nextten);

    tenyear.map(data => {
      months.push(
        <td
          key={data}
          className="calendar-month"
          onClick={e => {
            this.setYear(data);
          }}
        >
          <span>{data}</span>
        </td>
      );
    });
    let rows = [];
    let cells = [];

    months.forEach((row, i) => {
      if (i % 3 !== 0 || i == 0) {
        cells.push(row);
      } else {
        rows.push(cells);
        cells = [];
        cells.push(row);
      }
    });
    rows.push(cells);
    let yearlist = rows.map((d, i) => {
      return <tr>{d}</tr>;
    });

    return (
      <table className="calendar-month">
        <thead>
          <tr>
            <th colSpan="4">Select a Yeah</th>
          </tr>
        </thead>
        <tbody>{yearlist}</tbody>
      </table>
    );
  };
  onDayClick = (e, d) => {
    // alert(d)
    var datevalue=d
    if(d<10){
      datevalue="0"+d

    }
    this.setState(
      {
        selectedDay: datevalue
      },
      () => {
        console.log("SELECTED DAY: ", this.state.selectedDay);
        console.log(this.state.selectedDay.length)
      }
    );
  };

//   onMonthClick = (A, B) => {
//     this.setState(
//       {
//         selectedDay: B
//       },
//       () => {
//         console.log("SELECTED DAY: ", this.state.SelectedMonth);
//       }
//     );

// }


// componentwill mount lifecycle starts

componentWillMount(){
  var max=2100;
  var arr_valueyear = [];
  for(var min=1805;min<max;min++){
    arr_valueyear.push(<option>{min}</option>)
  }
  this.setState({arr_store_year:arr_valueyear})
  var months= ["January","February","March","April","May","June","July",
             "August","September","October","November","December"];
   var arr_valuemonth=[];
   for(var i=0;i<months.length;i++){
    var x=i==this.month()?"today":"";
    console.log(this.month(),"ghdfgj")
    arr_valuemonth.push(<option>{months[i]}</option>)
   }  

   this.setState({arr_store_month:arr_valuemonth})        

}

// To change Year 
yearFunc = (event) => {
  let year=event.target.value;
  let dateObject = Object.assign({}, this.state.dateObject);
    dateObject = moment(dateObject).set("year", year);
  this.setState({arr_store_year_value:event.target.value, arr_store_month_value: !this.state.arr_store_month_value, showDateTable: !this.state.showDateTable})
  this.setState({currentyear:year, showDateTable: this.state.showDateTable, dateObject: dateObject})
}

// To change Month
monthFunc = (event) => {
let month=event.target.value
console.log(month,"fgdhdhdhdhdhdhdhdhdhdhdhdhdhdhdhdhsf")
  let updatemonth=month.slice(0,3)
  let monthNo = this.state.allmonths.indexOf(month);
   let dateObject = Object.assign({}, this.state.dateObject);
    dateObject = moment(dateObject).set("month", monthNo);
  this.setState({arr_store_month_value:event.target.value,showDateTable: !this.state.showDateTable})
  this.setState({currentmonth:updatemonth,showDateTable:this.state.showDateTable,  dateObject: dateObject})
  

}
 
  render() {
    let weekdayshortname = this.weekdayshort.map(day => {
      return <th key={day}>{day}</th>;
    });
    let blanks = [];
    for (let i = 0; i < this.firstDayOfMonth(); i++) {
      blanks.push(<td className="calendar-day empty">{""}</td>);
    }
    let daysInMonth = [];
    for (let d = 1; d <= this.daysInMonth(); d++) {
      let currentDay = d == this.currentDay() ? "today" : "";
      daysInMonth.push(
        <td key={d} className={`calendar-day ${currentDay}`}>
          <span className="fuyutryt"
            onClick={e => {
              this.onDayClick(e, d);
            }}
          >
            {d}
          </span>
        </td>
      );
    }
    var totalSlots = [...blanks, ...daysInMonth];
    let rows = [];
    let cells = [];

    totalSlots.forEach((row, i) => {
      if (i % 7 !== 0) {
        cells.push(row);
      } else {
        rows.push(cells);
        cells = [];
        cells.push(row);
      }
      if (i === totalSlots.length - 1) {
        // let insertRow = cells.slice();
        rows.push(cells);
      }
    });

    let daysinmonth = rows.map((d, i) => {
      return <tr  value={this.state.selectedDate}
          onChange={this.handleDateChange}>{d}</tr>;
    });
    onchange=(e)=>
    {
      this.setState({arr_storemonth:e.target.value})
    }
 
    return (
      <div className="react_calendar">  
      <div className="tail-datetime-calendar">
        <div className="calendar-mainnavi">
       
            <div className="selectdate_mainnavimonth" colSpan="3"><div className="month_calculate">{this.state.currentmonth}</div>
            <div className="date_calculate">{this.state.selectedDay}</div>
            </div>
            <div className="selectdate_mainnaviyear">{this.state.currentyear}</div>
            <div className="selectdate_mainnaviday">{this.state.updatedcurrentDay}</div>
         
        </div>
        <div className="calendar-navi_container">
        <div className="calendar-navi">
        
          <span className="next_button"><img  className="previous" src={Next}
            onClick={e => {
              this.onPrev();
            }}
            
          /></span>
          
          <div>
          <div>
          <div>
          {!this.state.showMonthTable && (
           <span className="calendar-label"> 
           <div className="yearchoose_dropdown">
               <select class="browser-default custom-select"  onChange={this.yearFunc} value={this.state.
                arr_store_year_value}>
                <option>{this.year()}</option>
                {this.state.arr_store_year}
             </select>
             </div>
           </span>
           )}
           </div>
           </div>
           </div>

           <div>
           <div>
           <div>
           <span className="calendar-label">
           <div className="monthchoose_dropdown"> 
                  <select class="browser-default custom-select" onChange={this.monthFunc}  value={this.state.arr_store_month_value}
                  >
                 <option>{this.month()}</option>
                {this.state.arr_store_month}
                </select>
             </div>
          </span>
          </div>
          </div>
          </div>
           <span className="next_button"><div><img  className="next" src={Prev}
          onClick={e => {
            this.onNext();
          }}
         
        />
        </div>
        </span>
        </div>
        </div>
         <div>
        <div className="calendar-date">
          {this.state.showYearTable && <this.YearTable props={this.year()} />}
          {this.state.showMonthTable && (
            <this.MonthList data={moment.months()} />
          )}
        </div>

        {this.state.showDateTable && (
          <div className="calendar-date" style={{height:230}}>
            <table className="calendar-day">
              <thead>
                <tr>{weekdayshortname}</tr>
                
              </thead>
              <tbody  value={this.state.selectedDate}
          onChange={this.handleDateChange} onClick={this.onDayPress} className="table_cells">{daysinmonth}</tbody>
            </table>
          </div>
        )}
        </div>

        <div className="indicators-div">
         <div onClick={()=>{this.setState({fullyPopup:true})}} className="fullybooked_div"><div className="fullybooked_div1"><div className="fullybooked"></div></div><label className="indlabel_text">Booked</label> </div>
        <div><div className="partialbooked"></div></div><label className="indlabel_text">Total Available</label>
        </div>
      
        </div>
      
        
      
      </div>
    );
  }
}
 // {!this.state.showMonthTable && (
 //            <span
 //              onClick={e => {
 //                this.showMonth();
 //              }}
 //              class="calendar-label"
 //            >
 //              {this.month()}
 //            </span>
 //          )}

 export default CalendarBox;
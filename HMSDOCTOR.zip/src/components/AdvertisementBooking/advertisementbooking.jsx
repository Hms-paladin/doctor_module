
import React from 'react';
import Queue from './advertise_master.jsx'
import Calendar from './advertise_calendar'
import './advertisementbooking.css'
import './advertise_master.css'
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Labelbox from '../../helpers/labelbox/labelbox'
// import { Button } from 'reactstrap';
// import Button from '@material-ui/core/Button';
import { DatePicker } from 'antd';
import Checkbox from '@material-ui/core/Checkbox';
import PublishIcon from '@material-ui/icons/Publish';
import { Upload, message,Button, Icon } from 'antd';

const props = {
  name: 'file',
  action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
  headers: {
    authorization: 'authorization-text',
  },
  onChange(info) {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} file upload failed.`);
    }
  },
};
class Advertisement extends React.Component
{


render()
{
  return(
   <div className="doctor_advertisment_maincomp">
       <div><Queue/></div>
       <div className="paper_container">
       <div className="advertisepaper_div">
      <Paper className="paper"> 
      <Grid container>
      <Grid item xs={12} md={5}>
      <div className="calender_container">
      <div className="adversecalender_div">
      <div className="adversecalenderchild">
         <Calendar/>
      </div>
      </div>
      </div>
      </Grid>
           <Grid item xs={12} md={4}>
                       <div className="firstgrid-select">
                       <div className="firstgrid-selectdiv">
                               <div className="doctor_advertisement_dropdown">
                    <div className="duration_div">    
                     <div className="select_date1">
                          <Labelbox type="select" className="select" value=" " labelname="Duration"/>
              </div>

              <div className="doctor_advertisement_dropdown">
              <div><Labelbox type="datepicker" labelname="Start Date"/></div>
           </div>
           <div classNam><Labelbox className="totalcast" labelname="Total Cast" type="text"/></div>
         <div className="Checkbox-divcontainer">
         <div className="Checkbox-div"> <span><Checkbox
        value="checkedB"
        color="primary"
        inputProps={{
          'aria-label': 'secondary checkbox',
        }}/><label className="half">Half</label></span></div>
        <div><span><Checkbox
         className="half_checkbox"
        value="checkedB"
        color="primary"
        inputProps={{
          'aria-label': 'secondary checkbox',
        }}/><label className="full">Full</label></span></div>
      </div>
     
      </div>
      </div>  
                        </div>
                      </div>
                   </Grid>
                         <Grid item xs={12} md={3}>
                         <div className="third_gridcontainer">
                         <div className="third_gridcontainerdiv">
                         <div className="third_grid">
                       <div className="number_div"><Labelbox type="select" labelname="No.of Repeat"/></div>
                       <div className="date-div"><div><Labelbox type="datepicker" value="" labelname="End Date"/></div></div>
                       <div className="date-div"><p className="upload_text">Upload Advertisement</p><Upload {...props}><Button><span className="myimage_upload">My image.jpeg</span><button className="upload_buttoninside" value="fghgdjf">Browse</button></Button></Upload></div>
                       <div className="book_buttondivcontainer"><div className="book_button"><Button variant="contained" color="primary" className="button">Book</Button></div></div>
                        </div>       
                      </div>     
                       </div>

                   </Grid>

      </Grid>
      </Paper>
         </div>   
         </div>
         
  
         </div>      
               
              
             

  	)
}
}
export default Advertisement;